//
//  ManagerViewController.h
//  Courier
//
//  Created by 莫大宝 on 16/6/29.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManagerViewController : UIViewController

@property (nonatomic, strong) UIViewController *rootVC;


- (void)setRootVC:(UIViewController *)rootVC;

@end
