//
//  CourierInfo.m
//  peisongduan
//
//  Created by 莫大宝 on 16/6/23.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import "CourierInfoModel.h"

@implementation CourierInfoModel





@end
