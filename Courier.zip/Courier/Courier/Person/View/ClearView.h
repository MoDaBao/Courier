//
//  ClearView.h
//  peisongduan
//
//  Created by 莫大宝 on 16/6/21.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClearView : UIView

@property (nonatomic, assign) CGFloat margin;
@property (nonatomic, assign) CGFloat radius;

@end
