//
//  AppDelegate.h
//  Courier
//
//  Created by 莫大宝 on 16/6/29.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString *appKey = @"692787bd9088c49014bf5f84";
static NSString *channel = @"App Store";
static BOOL isProduction = FALSE;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

