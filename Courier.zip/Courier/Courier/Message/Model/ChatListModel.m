//
//  ChatListModel.m
//  Courier
//
//  Created by 莫大宝 on 16/7/27.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import "ChatListModel.h"

@implementation ChatListModel


- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}


@end
