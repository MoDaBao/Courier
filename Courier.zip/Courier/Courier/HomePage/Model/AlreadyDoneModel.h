//
//  AlreadyDoneModel.h
//  peisongduan
//
//  Created by 莫大宝 on 16/6/24.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import "BaseModel.h"

@interface AlreadyDoneModel : BaseModel

//@property (nonatomic, copy) NSString *_version_;
//@property (nonatomic, copy) NSString *all_price;
//@property (nonatomic, copy) NSString *bonus_id;
//@property (nonatomic, copy) NSString *bonus_price;
//@property (nonatomic, copy) NSString *buy_price;
//@property (nonatomic, copy) NSString *cancel_price;
//@property (nonatomic, copy) NSString *cancel_user;
//@property (nonatomic, copy) NSString *created;
//@property (nonatomic, copy) NSString *createuser;
//@property (nonatomic, copy) NSString *distance;
//@property (nonatomic, copy) NSString *distance_price;
//@property (nonatomic, copy) NSString *end;
//@property (nonatomic, copy) NSString *end_latitude;
//@property (nonatomic, copy) NSString *end_longitude;
//@property (nonatomic, copy) NSString *end_phone;
@property (nonatomic, copy) NSString *end_time;
//@property (nonatomic, copy) NSString *ID;
//@property (nonatomic, copy) NSString *is_cancel;
//@property (nonatomic, copy) NSString *is_del;
//@property (nonatomic, copy) NSString *is_evaluation;
//@property (nonatomic, copy) NSString *note;
//@property (nonatomic, copy) NSString *order_sn;
//@property (nonatomic, strong) NSNumber *pay_status;
@property (nonatomic, copy) NSString *pay_time;
//@property (nonatomic, strong) NSNumber *payment;
//@property (nonatomic, copy) NSString *pid;
//@property (nonatomic, copy) NSString *price;
//@property (nonatomic, copy) NSString *psend_time;
//@property (nonatomic, copy) NSString *puserphone;
//@property (nonatomic, copy) NSString *start;
//@property (nonatomic, copy) NSString *start_latitude;
//@property (nonatomic, copy) NSString *start_longitude;
//@property (nonatomic, copy) NSString *start_phone;
@property (nonatomic, copy) NSString *start_time;
//@property (nonatomic, copy) NSString *status;// 订单状态
//@property (nonatomic, strong) NSNumber *type;
//@property (nonatomic, copy) NSString *userid;
//@property (nonatomic, copy) NSString *userphone;
//@property (nonatomic, copy) NSString *version;

//puserphone = 13000000000;
//start = "屈臣氏(浙江台州椒江意得百货店) 附近";
//"start_latitude" = "28.652387";
//"start_longitude" = "121.413604";
//"start_phone" = "无";
//"start_time" = 1466739599;
//status = 5;
//type = 2;
//userid = 35;
//userphone = 13280197795;
//version = 1;


//"_version_" = 1537988025894567936;
//"all_price" = "0.01";
//"bonus_id" = 0;
//"bonus_price" = "0.0";
//"buy_price" = "0.0";
//"cancel_price" = "0.01";
//"cancel_user" = 0;
//created = "2016-06-24 11:37:51.0";
//createuser = 0;
//distance = 171;
//"distance_price" = "0.01";
//end = "意得百货 天和路88号(工商银行台州分行,天和大厦)";
//"end_latitude" = "28.653191";
//"end_longitude" = "121.413162";
//"end_phone" = 13280197795;
//"end_time" = 1466739676;
//id = 1941;
//"is_cancel" = 0;
//"is_del" = 0;
//"is_evaluation" = 0;
//ltime = "2016-06-24 11:41:16.0";
//note = "";
//"order_sn" = 14667394696263;
//"pay_status" = 1;
//"pay_time" = "2016-06-24 11:41:16.0";
//payment = 4;
//pid = 16;
//price = "0.01";
//"psend_time" = "尽快送达";

@end
