//
//  DeliveryModel.h
//  peisongduan
//
//  Created by 莫大宝 on 16/6/27.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import "BaseModel.h"

@interface DeliveryModel : BaseModel

//@property (nonatomic, copy) NSString *_version_;
//@property (nonatomic, copy) NSString *all_price;
//@property (nonatomic, copy) NSString *bonus_id;
//@property (nonatomic, copy) NSString *bonus_price;
//@property (nonatomic, copy) NSString *buy_price;
//@property (nonatomic, copy) NSString *cancel_price;
//@property (nonatomic, copy) NSString *cancel_user;
//@property (nonatomic, copy) NSString *created;
//@property (nonatomic, copy) NSString *createuser;
//@property (nonatomic, copy) NSString *distance;
//@property (nonatomic, copy) NSString *distance_price;
//@property (nonatomic, copy) NSString *end;
//@property (nonatomic, copy) NSString *end_latitude;
//@property (nonatomic, copy) NSString *end_longitude;
//@property (nonatomic, copy) NSString *end_phone;
//@property (nonatomic, copy) NSString *ID;
//@property (nonatomic, copy) NSString *is_cancel;
//@property (nonatomic, copy) NSString *is_del;
//@property (nonatomic, copy) NSString *is_evaluation;
//@property (nonatomic, copy) NSString *ltime;
//@property (nonatomic, copy) NSString *note;
//@property (nonatomic, copy) NSString *order_sn;
//@property (nonatomic, copy) NSString *pay_status;
//@property (nonatomic, copy) NSString *payment;
//@property (nonatomic, copy) NSString *pid;
//@property (nonatomic, copy) NSString *price;
//@property (nonatomic, copy) NSString *psend_time;
//@property (nonatomic, copy) NSString *puserphone;
//@property (nonatomic, copy) NSString *start;
//@property (nonatomic, copy) NSString *start_latitude;
//@property (nonatomic, copy) NSString *start_longitude;
//@property (nonatomic, copy) NSString *start_phone;
//@property (nonatomic, copy) NSString *status;
//@property (nonatomic, strong) NSNumber *type;
//@property (nonatomic, copy) NSString *userid;
//@property (nonatomic, copy) NSString *userphone;
//@property (nonatomic, copy) NSString *version;




//"_version_" = 1538252119360929792;
//"all_price" = "0.01";
//"bonus_id" = 0;
//"bonus_price" = "0.0";
//"buy_price" = "0.0";
//"cancel_price" = "0.01";
//"cancel_user" = 0;
//created = "2016-06-27 09:32:04.0";
//createuser = 0;
//distance = 3000;
//"distance_price" = "0.01";
//end = "";
//"end_latitude" = "28.65323377";
//"end_longitude" = "121.4137836";
//"end_phone" = 18652939234;
//id = 2033;
//"is_cancel" = 0;
//"is_del" = 0;
//"is_evaluation" = 0;
//ltime = "2016-06-27 09:38:06.0";
//note = "";
//"order_sn" = 14669911243905;
//"pay_status" = 0;
//payment = 4;
//pid = 16;
//price = "0.01";
//"psend_time" = "尽快送达";
//puserphone = 13000000000;
//start = "";
//"start_latitude" = "28.65323377";
//"start_longitude" = "121.4137836";
//"start_phone" = "无";
//status = 2;
//type = 2;
//userid = 22;
//userphone = 18652939234;
//version = 1;

@end
