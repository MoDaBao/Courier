//
//  WaitOrdrReceivingModel.h
//  Courier
//
//  Created by 莫大宝 on 16/6/30.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import "BaseModel.h"

@interface WaitOrdrReceivingModel : BaseModel

//@property (nonatomic, copy) NSString *all_price;
//@property (nonatomic, copy) NSString *bonus_id;
//@property (nonatomic, copy) NSString *bonus_price;
//@property (nonatomic, copy) NSString *buy_price;
@property (nonatomic, copy) NSString *cancel_note;
//@property (nonatomic, copy) NSString *cancel_price;
//@property (nonatomic, copy) NSString *cancel_user;
//@property (nonatomic, copy) NSString *created;
//@property (nonatomic, copy) NSString *createuser;
//@property (nonatomic, copy) NSString *distance;
//@property (nonatomic, copy) NSString *distance_price;
//@property (nonatomic, copy) NSString *end;
//@property (nonatomic, copy) NSString *end_latitude;
//@property (nonatomic, copy) NSString *end_longitude;
//@property (nonatomic, copy) NSString *end_phone;
@property (nonatomic, copy) NSString *end_time;
//@property (nonatomic, copy) NSString *ID;
//@property (nonatomic, copy) NSString *is_cancel;
//@property (nonatomic, copy) NSString *is_del;
//@property (nonatomic, copy) NSString *is_evaluation;
//@property (nonatomic, copy) NSString *ltime;
//@property (nonatomic, copy) NSString *note;
//@property (nonatomic, copy) NSString *order_sn;
//@property (nonatomic, copy) NSString *pay_status;
@property (nonatomic, copy) NSString *pay_time;
//@property (nonatomic, copy) NSString *payment;
//@property (nonatomic, copy) NSString *pid;
//@property (nonatomic, copy) NSString *price;
//@property (nonatomic, copy) NSString *psend_time;
//@property (nonatomic, copy) NSString *puserphone;
//@property (nonatomic, copy) NSString *start;
//@property (nonatomic, copy) NSString *start_latitude;
//@property (nonatomic, copy) NSString *start_longitude;
//@property (nonatomic, copy) NSString *start_phone;
@property (nonatomic, copy) NSString *start_time;
//@property (nonatomic, copy) NSString *status;
//@property (nonatomic, copy) NSString *type;
//@property (nonatomic, copy) NSString *userid;
//@property (nonatomic, copy) NSString *userphone;
//@property (nonatomic, copy) NSString *version;

//pid = 0;
//price = 0;
//"psend_time" = "尽快送达";
//puserphone = "<null>";
//start = "<null>";
//"start_latitude" = "<null>";
//"start_longitude" = "<null>";
//"start_phone" = "<null>";
//"start_time" = "<null>";
//status = 1;
//type = 3;
//userid = 7;
//userphone = 18700932962;
//version = 1;

//"all_price" = 0;
//"bonus_id" = 0;
//"bonus_price" = 0;
//"buy_price" = 0;
//"cancel_note" = "<null>";
//"cancel_price" = 0;
//"cancel_user" = 0;
//created = "2016-06-30 13:56:27";
//createuser = 1;
//distance = 0;
//"distance_price" = 0;
//end = "<null>";
//"end_latitude" = "<null>";
//"end_longitude" = "<null>";
//"end_phone" = "<null>";
//"end_time" = "<null>";
//id = 110;
//"is_cancel" = 0;
//"is_del" = 0;
//"is_evaluation" = 0;
//ltime = "2016-06-30 13:56:27";
//note = "<null>";
//"order_sn" = 14672661874128;
//"pay_status" = 0;
//"pay_time" = "<null>";
//payment = 0;

@end
