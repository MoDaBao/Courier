//
//  TestMessageCell.h
//  Courier
//
//  Created by 莫大宝 on 16/7/20.
//  Copyright © 2016年 dabao. All rights reserved.
//

#import <RongIMKit/RongIMKit.h>

@interface TestMessageCell : RCMessageBaseCell

@end
